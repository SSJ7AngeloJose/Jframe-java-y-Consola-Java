/**
 * 
 */
/**
 * 
 */
module ListaEmpleados {
    requires java.desktop; // Necesario para usar las clases de Swing

    exports listaempleadosJframeJava;
    exports listaempleadosJframe;
}
