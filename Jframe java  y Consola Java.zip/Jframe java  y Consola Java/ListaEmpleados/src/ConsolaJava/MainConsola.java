package ConsolaJava;

public class MainConsola {
    public static void main(String[] args) {
        ListaEmpleado lista = new ListaEmpleado();

        // Ingresar empleados
        lista.ingresar(1, "Juan Perez", 3000.0, 500.0);
        lista.ingresar(2, "Maria Lopez", 2500.0, 300.0);

        // Imprimir empleados
        lista.imprimirEmpleados();

        // Buscar un empleado
        NodoEmpleado empleado = lista.buscar(1);
        if (empleado != null) {
            System.out.println("Empleado encontrado: " + empleado.getNombre());
        }

        // Modificar un empleado
        lista.modificar(1, "Juan Perez Modificado", 3200.0, 600.0);
        lista.actualizar();

        // Imprimir empleados después de modificar
        lista.imprimirEmpleados();

        // Eliminar un empleado
        lista.eliminar(2);
        lista.imprimirEmpleados();
    }
}