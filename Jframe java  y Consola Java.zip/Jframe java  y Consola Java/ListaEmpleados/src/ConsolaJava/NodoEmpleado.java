package ConsolaJava;

public class NodoEmpleado {
 
		private int codigo;
		private String nombre;
		private double sueldo;
		private double comisiones;
		private NodoEmpleado siguiente;
		
		public NodoEmpleado(int codigo, String nombre, double sueldo, double comisiones) {
			super();
			this.codigo = codigo;
			this.nombre = nombre;
			this.sueldo = sueldo;
			this.comisiones = comisiones;
			this.siguiente = null;
		}

		public int getCodigo() {
			return codigo;
		}

		public void setCodigo(int codigo) {
			this.codigo = codigo;
		}

		public String getNombre() {
			return nombre;
		}

		public void setNombre(String nombre) {
			this.nombre = nombre;
		}

		public double getSueldo() {
			return sueldo;
		}

		public void setSueldo(double sueldo) {
			this.sueldo = sueldo;
		}

		public double getComisiones() {
			return comisiones;
		}

		public void setComisiones(double comisiones) {
			this.comisiones = comisiones;
		}

		public NodoEmpleado getSiguiente() {
			return siguiente;
		}

		public void setSiguiente(NodoEmpleado siguiente) {
			this.siguiente = siguiente;
		}
	 
		//metodos complementarios
		public double sueldoBruto() {
			return this.sueldo + this.comisiones;
		}
		
	    public double sueldoNeto() {
	        return this.sueldoBruto() * 0.87; // Restando 13% por AFP
	    }
		
		public double afp() {
			return this.sueldoBruto()* 0.13;
		}
		public String correo() {
			return this.nombre + "@ucvirtual.edu.pe";
		}
	}