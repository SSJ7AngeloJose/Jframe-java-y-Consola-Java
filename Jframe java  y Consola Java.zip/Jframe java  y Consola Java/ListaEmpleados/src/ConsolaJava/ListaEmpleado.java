package ConsolaJava;

public class ListaEmpleado {
    private NodoEmpleado cabeza;

    public ListaEmpleado() {
        this.cabeza = null;
    }

    // Método para ingresar un nuevo empleado
    public void ingresar(int codigo, String nombre, double sueldo, double comisiones) {
        NodoEmpleado nuevo = new NodoEmpleado(codigo, nombre, sueldo, comisiones);
        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            NodoEmpleado actual = cabeza;
            while (actual.getSiguiente() != null) {
                actual = actual.getSiguiente();
            }
            actual.setSiguiente(nuevo);
        }
    }

    // Método para buscar un empleado por código
    public NodoEmpleado buscar(int codigo) {
        NodoEmpleado actual = cabeza;
        while (actual != null) {
            if (actual.getCodigo() == codigo) {
                return actual;
            }
            actual = actual.getSiguiente();
        }
        return null;
    }

    // Método para eliminar un empleado por código
    public void eliminar(int codigo) {
        if (cabeza == null) {
            return;
        }

        if (cabeza.getCodigo() == codigo) {
            cabeza = cabeza.getSiguiente();
            return;
        }

        NodoEmpleado actual = cabeza;
        while (actual.getSiguiente() != null) {
            if (actual.getSiguiente().getCodigo() == codigo) {
                actual.setSiguiente(actual.getSiguiente().getSiguiente());
                return;
            }
            actual = actual.getSiguiente();
        }
    }

    // Método para modificar los datos de un empleado
    public void modificar(int codigo, String nuevoNombre, double nuevoSueldo, double nuevasComisiones) {
        NodoEmpleado actual = buscar(codigo);
        if (actual != null) {
            actual.setNombre(nuevoNombre);
            actual.setSueldo(nuevoSueldo);
            actual.setComisiones(nuevasComisiones);
        }
    }

    // Método para actualizar la lista después de una modificación
    public void actualizar() {
        // Este método puede ser utilizado para cualquier acción adicional después de modificar.
    }

    // Método para imprimir todos los empleados
    public void imprimirEmpleados() {
        NodoEmpleado actual = cabeza;
        while (actual != null) {
            System.out.println("Código: " + actual.getCodigo());
            System.out.println("Nombre: " + actual.getNombre());
            System.out.println("Sueldo: " + actual.getSueldo());
            System.out.println("Comisiones: " + actual.getComisiones());
            System.out.println("Sueldo Bruto: " + actual.sueldoBruto());
            System.out.println("Sueldo Neto: " + actual.sueldoNeto());
            System.out.println("AFP: " + actual.afp());
            System.out.println("Correo: " + actual.correo());
            System.out.println();
            actual = actual.getSiguiente();
        }
    }
}