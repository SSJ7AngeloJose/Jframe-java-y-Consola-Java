package listaempleadosJframe;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import listaempleadosJframeJava.ListaEmpleados;
import listaempleadosJframeJava.NodoEmpleado;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ListaEmpleado extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField codigos;
    private JTextField nombres;
    private JTextField sueldos;
    private JTextField comisioness;
    private JTextArea mostrar;
    private ListaEmpleados listaEmpleados = new ListaEmpleados();

    /**
     * Launch the application.
     */
     

    /**
     * Create the frame.
     */
    public ListaEmpleado() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 647, 559);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel tablatitle = new JLabel("Tabla ");
        tablatitle.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 17));
        tablatitle.setBounds(249, 43, 205, 14);
        contentPane.add(tablatitle);

        JLabel codigo = new JLabel("Código");
        codigo.setBounds(80, 116, 46, 14);
        contentPane.add(codigo);

        JLabel nombre = new JLabel("Nombre");
        nombre.setBounds(80, 157, 46, 14);
        contentPane.add(nombre);

        JLabel sueldo = new JLabel("Sueldo");
        sueldo.setBounds(80, 205, 46, 14);
        contentPane.add(sueldo);

        JLabel comisiones = new JLabel("Comisiones");
        comisiones.setBounds(80, 242, 89, 14);
        contentPane.add(comisiones);

        codigos = new JTextField();
        codigos.setBounds(246, 113, 86, 20);
        contentPane.add(codigos);
        codigos.setColumns(10);

        nombres = new JTextField();
        nombres.setBounds(246, 154, 86, 20);
        contentPane.add(nombres);
        nombres.setColumns(10);

        sueldos = new JTextField();
        sueldos.setBounds(249, 202, 86, 20);
        contentPane.add(sueldos);
        sueldos.setColumns(10);

        comisioness = new JTextField();
        comisioness.setBounds(246, 239, 86, 20);
        contentPane.add(comisioness);
        comisioness.setColumns(10);

        JButton ingresar = new JButton("Ingresar");
        ingresar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ingresarEmpleado();
            }
        });
        ingresar.setBounds(80, 297, 89, 23);
        contentPane.add(ingresar);

        JButton buscar = new JButton("Buscar");
        buscar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                buscarEmpleado();
            }
        });
        buscar.setBounds(204, 297, 89, 23);
        contentPane.add(buscar);

        JButton eliminar = new JButton("Eliminar");
        eliminar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                eliminarEmpleado();
            }
        });
        eliminar.setBounds(341, 297, 89, 23);
        contentPane.add(eliminar);

        JButton modificar = new JButton("Modificar");
        modificar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                modificarEmpleado();
            }
        });
        modificar.setBounds(488, 297, 89, 23);
        contentPane.add(modificar);

        mostrar = new JTextArea();
        mostrar.setBounds(10, 340, 611, 169);
        contentPane.add(mostrar);
    }

    private void ingresarEmpleado() {
        int codigo = Integer.parseInt(codigos.getText());
        String nombre = nombres.getText();
        double sueldo = Double.parseDouble(sueldos.getText());
        double comisiones = Double.parseDouble(comisioness.getText());

        listaEmpleados.ingresar(new NodoEmpleado(codigo, nombre, sueldo, comisiones));
        mostrarEmpleados();
    }

    private void buscarEmpleado() {
        int codigo = Integer.parseInt(codigos.getText());
        NodoEmpleado empleado = listaEmpleados.buscar(codigo);
        if (empleado != null) {
            mostrar.setText("Empleado encontrado:\n" + empleado);
        } else {
            mostrar.setText("Empleado no encontrado.");
        }
    }

    private void eliminarEmpleado() {
        int codigo = Integer.parseInt(codigos.getText());
        listaEmpleados.eliminar(codigo);
        mostrarEmpleados();
    }

    private void modificarEmpleado() {
        int codigo = Integer.parseInt(codigos.getText());
        String nombre = nombres.getText();
        double sueldo = Double.parseDouble(sueldos.getText());
        double comisiones = Double.parseDouble(comisioness.getText());

        listaEmpleados.modificar(codigo, nombre, sueldo, comisiones);
        mostrarEmpleados();
    }

    private void mostrarEmpleados() {
        StringBuilder sb = new StringBuilder();
        NodoEmpleado actual = listaEmpleados.getHead();
        while (actual != null) {
            sb.append(actual).append("\n\n");
            actual = actual.getSiguiente();
        }
        mostrar.setText(sb.toString());
    }
}

