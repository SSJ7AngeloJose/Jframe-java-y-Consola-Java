package listaempleadosJframeJava;

 

public class ListaEmpleados {
    private NodoEmpleado head;

    public void ingresar(NodoEmpleado nuevo) {
        if (head == null) {
            head = nuevo;
        } else {
            NodoEmpleado actual = head;
            while (actual.getSiguiente() != null) {
                actual = actual.getSiguiente();
            }
            actual.setSiguiente(nuevo);
        }
    }

    public NodoEmpleado buscar(int codigo) {
        NodoEmpleado actual = head;
        while (actual != null) {
            if (actual.getCodigo() == codigo) {
                return actual;
            }
            actual = actual.getSiguiente();
        }
        return null;
    }

    public void eliminar(int codigo) {
        if (head != null) {
            if (head.getCodigo() == codigo) {
                head = head.getSiguiente();
            } else {
                NodoEmpleado actual = head;
                while (actual.getSiguiente() != null) {
                    if (actual.getSiguiente().getCodigo() == codigo) {
                        actual.setSiguiente(actual.getSiguiente().getSiguiente());
                        break;
                    }
                    actual = actual.getSiguiente();
                }
            }
        }
    }

    public void modificar(int codigo, String nombre, double sueldo, double comisiones) {
        NodoEmpleado actual = buscar(codigo);
        if (actual != null) {
            actual.setNombre(nombre);
            actual.setSueldo(sueldo);
            actual.setComisiones(comisiones);
        }
    }

    public NodoEmpleado getHead() {
        return head;
    }
}
